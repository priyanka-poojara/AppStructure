//
//  StringScheme+APIKeys.swift
//  Plutope
//
//  Created by Priyanka Poojara on 27/06/23.
//

import Foundation

struct APIKey {
    /// Write here all API Keys for app
}
