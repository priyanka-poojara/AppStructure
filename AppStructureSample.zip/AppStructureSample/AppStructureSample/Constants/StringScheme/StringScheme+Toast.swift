//
//  StringScheme+Toast.swift
//  Plutope
//
//  Created by Priyanka Poojara on 23/06/23.
//

import Foundation

struct ToastValidation {
    
    /// Write here all toast validation messages for the app
    
    static func lowBalance(_ coinSymbol: String) -> String {
        return "You don't have enough \(coinSymbol) in your account."
    }
    
}
