//
//  StringScheme+URLs.swift
//  Plutope
//
//  Created by Priyanka Poojara on 03/07/23.
//

import Foundation
 
struct URLs {
    static let privacyUrl: String = "www.google.com"
    static let termConditionUrl: String = "www.google.com"
}
