//
//  StringScheme.swift
//  Plutope
//
//  Created by Priyanka Poojara on 31/05/23.
//

import UIKit

struct StringConstants {
    /// Write here all Strings for app
    static let loreumIpsum = "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna."
    
}

// MARK: User Defaults keys
struct DefaultsKey {
   
}
