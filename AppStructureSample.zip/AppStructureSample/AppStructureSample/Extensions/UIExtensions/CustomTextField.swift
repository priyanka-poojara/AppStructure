//
//  CustomTextField.swift
//  Plutope
//
//  Created by Priyanka Poojara on 05/06/23.
//

import UIKit

@IBDesignable class CustomTextField: UITextField {
  
    @IBInspectable
    var leftSpacing: CGFloat = 0 {
        didSet {
            setTextField(rightSpacing: rightSpacing, leftSpacing: leftSpacing)
        }
    }
    
    @IBInspectable
    var rightSpacing: CGFloat = 0 {
        didSet {
            setTextField(rightSpacing: rightSpacing, leftSpacing: leftSpacing)
        }
    }
    
    private func setTextField(rightSpacing: CGFloat = 0, leftSpacing: CGFloat = 0) {
       
        let leftIconContainerView: UIView = UIView(frame:CGRect(x: 20, y: 0, width: leftSpacing, height: self.frame.height))
        leftView = leftIconContainerView
        leftViewMode = .always
        let rightIconContainerView: UIView = UIView(frame: CGRect(x: 20, y: 0, width: rightSpacing, height: self.frame.height))
        rightView = rightIconContainerView
        rightViewMode = .always
    }
    
}
