//
//  UIExtensions.swift
//  Plutope
//
//  Created by Priyanka Poojara on 02/06/23.
//

import UIKit
private var kAssociationKeyMaxLength: Int = 0

@IBDesignable
class DesignableView: UIView {
}

@IBDesignable
class DesignableButton: UIButton {
}

@IBDesignable
class DesignableLabel: UILabel {
}

@IBDesignable
class SpinnerView : UIView {

    override var layer: CAShapeLayer {
        return super.layer as? CAShapeLayer ?? CAShapeLayer()
    }

    override class var layerClass: AnyClass {
        return CAShapeLayer.self
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        layer.fillColor = nil
        layer.strokeColor = UIColor.init(named: "#E84118-1")?.withAlphaComponent(0.50).cgColor
        layer.lineWidth = 3
        setPath()
    }

    override func didMoveToWindow() {
        animate()
    }

    private func setPath() {
        layer.path = UIBezierPath(ovalIn: bounds.insetBy(dx: layer.lineWidth / 2, dy: layer.lineWidth / 2)).cgPath
    }

    struct Pose {
        let secondsSincePriorPose: CFTimeInterval
        let start: CGFloat
        let length: CGFloat
        init(_ secondsSincePriorPose: CFTimeInterval, _ start: CGFloat, _ length: CGFloat) {
            self.secondsSincePriorPose = secondsSincePriorPose
            self.start = start
            self.length = length
        }
    }

    class var poses: [Pose] {
        get {
            return [
                Pose(0.0, 0.000, 0.7),
                Pose(0.6, 0.500, 0.5),
                Pose(0.6, 1.000, 0.3),
                Pose(0.6, 1.500, 0.1),
                Pose(0.2, 1.875, 0.1),
                Pose(0.2, 2.250, 0.3),
                Pose(0.2, 2.625, 0.5),
                Pose(0.2, 3.000, 0.7)
            ]
            
        }
    }

    func animate() {
        var time: CFTimeInterval = 0
        var times = [CFTimeInterval]()
        var start: CGFloat = 0
        var rotations = [CGFloat]()
        var strokeEnds = [CGFloat]()

        let poses = type(of: self).poses
        let totalSeconds = poses.reduce(0) { $0 + $1.secondsSincePriorPose }

        for pose in poses {
            time += pose.secondsSincePriorPose
            times.append(time / totalSeconds)
            start = pose.start
            rotations.append(start * 2 * .pi)
            strokeEnds.append(pose.length)
        }

        times.append(times.last!)
        rotations.append(rotations[0])
        strokeEnds.append(strokeEnds[0])

        animateKeyPath(keyPath: "strokeEnd", duration: totalSeconds, times: times, values: strokeEnds)
        animateKeyPath(keyPath: "transform.rotation", duration: totalSeconds, times: times, values: rotations)

       // animateStrokeHueWithDuration(duration: totalSeconds * 5)
    }

    func animateKeyPath(keyPath: String, duration: CFTimeInterval, times: [CFTimeInterval], values: [CGFloat]) {
        let animation = CAKeyframeAnimation(keyPath: keyPath)
        animation.keyTimes = times as [NSNumber]?
        animation.values = values
        animation.calculationMode = .linear
        animation.duration = duration
        animation.repeatCount = Float.infinity
        layer.add(animation, forKey: animation.keyPath)
    }
    
    func animateStrokeHueWithDuration(duration: CFTimeInterval) {
        let count = 36
        let animation = CAKeyframeAnimation(keyPath: "strokeColor")
        animation.keyTimes = (0 ... count).map { NSNumber(value: CFTimeInterval($0) / CFTimeInterval(count)) }
        for i in 0 ... count {
            animation.values?[i] = UIColor.init(named: "#E84118-1")?.cgColor
        }
        
        animation.duration = duration
        animation.calculationMode = .linear
        animation.repeatCount = Float.infinity
        layer.add(animation, forKey: animation.keyPath)
    }

}

// MARK: - UIView Styling Extensions
/// These extensions cover various styling properties for UIViews:
///
/// - `cornerRadius`: The corner radius of the view's layer.
/// - `borderWidth`: The width of the view's border.
/// - `borderColor`: The color of the view's border.
/// - `shadowRadius`: The radius of the view's shadow.
/// - `shadowOpacity`: The opacity of the view's shadow.
/// - `shadowOffset`: The offset of the view's shadow.
/// - `shadowColor`: The color of the view's shadow.
extension UIView {
    /// Individual corner radius
    func roundCorners(corners: UIRectCorner, radius: CGFloat) {
        let path = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let mask = CAShapeLayer()
        mask.path = path.cgPath
        layer.mask = mask
    }
    
    @IBInspectable
    var masksToBounds: Bool {
        get {
            return layer.masksToBounds
        }
        set {
            layer.masksToBounds = newValue
        }
    }
    
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
        }
    }
    
    @IBInspectable
    var maskCorners: CACornerMask {
        get {
            return layer.maskedCorners
        }
        set {
            layer.maskedCorners = newValue
            clipsToBounds = true
        }
    }

    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable
    var borderColor: UIColor? {
        get {
            if let color = layer.borderColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.borderColor = color.cgColor
            } else {
                layer.borderColor = nil
            }
        }
    }
    
    @IBInspectable
    var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    
    @IBInspectable
    var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable
    var shadowOffset: CGSize {
        get {
            return layer.shadowOffset
        }
        set {
            layer.shadowOffset = newValue
        }
    }
    
    @IBInspectable
    var shadowColor: UIColor? {
        get {
            if let color = layer.shadowColor {
                return UIColor(cgColor: color)
            }
            return nil
        }
        set {
            if let color = newValue {
                layer.shadowColor = color.cgColor
            } else {
                layer.shadowColor = nil
            }
        }
    }
    
}

// MARK: - UITextField Styling Extensions
/// These extensions cover various styling properties for UITextField:
///
/// - `maxLength`: The maximum length of character.
/// - `placeHolderColor`: The placeHolder Color of the textfield.
extension UITextField {
    @IBInspectable var maxLength: Int {
        get {
            if let length = objc_getAssociatedObject(self, &kAssociationKeyMaxLength) as? Int {
                return length
            } else {
                return Int.max
            }
        }
        set {
            objc_setAssociatedObject(self, &kAssociationKeyMaxLength, newValue, .OBJC_ASSOCIATION_RETAIN)
            self.addTarget(self, action: #selector(checkMaxLength), for: .editingChanged)
        }
    }
    
    //The method is used to cancel the check when use Chinese Pinyin input method.
    //Becuase the alphabet also appears in the textfield when inputting, we should cancel the check.
    func isInputMethod() -> Bool {
        if let positionRange = self.markedTextRange {
            if let _ = self.position(from: positionRange.start, offset: 0) {
                return true
            }
        }
        return false
    }
    
    @objc func checkMaxLength(textField: UITextField) {
        
        guard !self.isInputMethod(), let prospectiveText = self.text,
              prospectiveText.count > maxLength
        else {
            return
        }
        
        let selection = selectedTextRange
        let maxCharIndex = prospectiveText.index(prospectiveText.startIndex, offsetBy: maxLength)
        text = prospectiveText.substring(to: maxCharIndex)
        selectedTextRange = selection
    }
    
    @IBInspectable var placeHolderColor: UIColor? {
        get {
            return self.placeHolderColor
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string:self.placeholder != nil ? self.placeholder!: "", attributes:[NSAttributedString.Key.foregroundColor: newValue!])
        }
    }
}

// MARK: - UILabel Styling Extensions
/// These extensions provide styling options for UILabels:
///
/// - `lineHeight`: Adjusts the line height for paragraph text.
extension UILabel {
    
    @IBInspectable var lineHeight: CGFloat {
        get {
            guard let paragraphStyle = attributedText?.attribute(NSAttributedString.Key.paragraphStyle, at: 0, effectiveRange: nil) as? NSParagraphStyle else {
                return 0
            }
            return paragraphStyle.lineSpacing + font.lineHeight
        }
        set {
            
            let attributedString = NSMutableAttributedString(string: text ?? "")
            
            let paragraphStyle = NSMutableParagraphStyle()
            
            paragraphStyle.alignment = self.textAlignment
            
            var space = newValue
            
            if let LSpace = newValue as? CGFloat {
                
                space = LSpace - self.font.pointSize - (self.font.lineHeight - self.font.pointSize)
                
                paragraphStyle.lineSpacing = space
                
                attributedString.addAttribute(
                    NSAttributedString.Key.paragraphStyle,
                    value: paragraphStyle,
                    range: NSRange(location: 0, length: attributedString.length))
                
                attributedText = attributedString
            }
        }
    }
}

// MARK: - String Styling Extensions
/// These extensions provide styling options for String:
///
/// - `capitalizingFirstLetter`: It will capitalize first letter of any string.
/// - `stringToImage`: Will convert string to image.
extension String {
    func capitalizingFirstLetter() -> String {
        return prefix(1).uppercased() + self.lowercased().dropFirst()
    }
    
    /// Convert string to UIImage
    func stringToImage() -> UIImage? {
        let size = CGSize(width: 40, height: 40)
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        UIColor.white.set()
        let rect = CGRect(origin: .zero, size: size)
        UIRectFill(CGRect(origin: .zero, size: size))
        (self as AnyObject).draw(in: rect, withAttributes: [.font: UIFont.systemFont(ofSize: 40)])
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
}

/// Tap Gesture extension
extension UIView {
    func addTapGesture(target: Any, action: Selector) {
        let tapGesture = UITapGestureRecognizer(target: target, action: action)
        self.isUserInteractionEnabled = true
        self.addGestureRecognizer(tapGesture)
    }
}

// MARK: - UIScrollView Extension
///
/// - `addRefreshControl`: It will add refreshcontrol to scrollview, tableview.
extension UIScrollView {
    func addRefreshControl(target: Any, action: Selector) {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(target, action: action, for: .valueChanged)
        refreshControl.tintColor = .white
        if #available(iOS 10.0, *) {
            self.refreshControl = refreshControl
        } else {
            addSubview(refreshControl)
        }
    }
    
    func endRefreshing() {
        if #available(iOS 10.0, *) {
            refreshControl?.endRefreshing()
        }
    }
}

/// - Custom Class to update contraint values according to the mobilke devices
/// - Will check that weather device is notched or not
/// - Then apply constant value to your view
class NotchedConstraintConstant: NSLayoutConstraint {
    
    var mainConstant: CGFloat = 0 // Main Constant to hold the default value
    
    @IBInspectable var nonNotchedConst: CGFloat = 0 {
        didSet {
            if enableDynamicHeight {
                setUpConstraint()
            }
        }
    }
    
    @IBInspectable var notchedConst: CGFloat = 0 {
        didSet {
            if enableDynamicHeight {
                setUpConstraint()
            }
        }
    }
    
    /// Only enablig this will trigger the prorata
    fileprivate func setUpConstraint() {
        if UIDevice.current.hasNotch == false { // if prorata is enabled change the constant value
            
            self.constant = nonNotchedConst
            
        } else {
            
            self.constant = notchedConst
            
        }
    }
    
    @IBInspectable
    var enableDynamicHeight: Bool = false {
        didSet {
            mainConstant = constant
            if enableDynamicHeight {
                setUpConstraint()
            }
        }
    }
}

/// Will check that device is notched or not
extension UIDevice {
    var hasNotch: Bool {
        if #available(iOS 11.0, *) {
            let bottom = UIApplication.shared.keyWindow?.safeAreaInsets.bottom ?? 0
            return bottom > 0
        } else {
            // Fallback on earlier versions
            return false
        }
    }
}
