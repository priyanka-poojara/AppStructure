//
//  ViewExtension.swift
//  Plutope
//
//  Created by Priyanka Poojara on 02/06/23.
//

import UIKit

extension UIViewController{
    
    func defineHeader(headerView: UIView, titleText: String, btnBackHidden: Bool = false, btnRightImage: UIImage? = nil, btnRightAction: ( () -> Void)? = nil) {
        
        let header = Bundle.main.loadNibNamed("NavigationView", owner: nil, options: nil)?.first as? NavigationView
        header?.currentViewController = self.navigationController ?? UINavigationController()
        
        header?.lblTitle.text = titleText
        header?.btnBack.isHidden = btnBackHidden
      
        header?.btnRight.setImage(btnRightImage, for: .normal)
        
        if let graphAction = btnRightAction {
            header?.btnRight.addTarget(self, action: #selector(handleBtnGraphTap(_:)), for: .touchUpInside)
            // Store the graph action closure in the button's tag
            header?.btnRight.tag = 1
            // Associate the closure with the view controller
            objc_setAssociatedObject(self, &AssociatedKeys.graphActionClosure, graphAction, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
        }
        
        headerView.addSubview(header ?? UIView())
        header?.translatesAutoresizingMaskIntoConstraints = false
        header?.topAnchor.constraint(equalTo: headerView.topAnchor).isActive = true
        header?.bottomAnchor.constraint(equalTo: headerView.bottomAnchor).isActive = true
        header?.leadingAnchor.constraint(equalTo: headerView.leadingAnchor).isActive = true
        header?.trailingAnchor.constraint(equalTo: headerView.trailingAnchor).isActive = true
        
    }
    
    @objc private func handleBtnGraphTap(_ sender: UIButton) {
        if sender.tag == 1 {
            // Retrieve the associated closure and invoke it
            if let graphAction = objc_getAssociatedObject(self, &AssociatedKeys.graphActionClosure) as? () -> Void {
                graphAction()
            }
        }
    }
    private struct AssociatedKeys {
        static var graphActionClosure = "graphActionClosure"
    }
}
