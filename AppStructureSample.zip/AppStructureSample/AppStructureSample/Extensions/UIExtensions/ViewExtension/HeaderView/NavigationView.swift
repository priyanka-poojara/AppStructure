//
//  NavigationView.swift
//  Plutope
//
//  Created by Priyanka Poojara on 02/06/23.
//

import UIKit

class NavigationView: UIView {
    
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var btnNotification: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var btnRight: UIButton!
    
    var currentViewController: UINavigationController? = nil
    
    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }
    
    @IBAction func actionNotification(_ sender: Any) {
        
    }
    
    @IBAction func actionBack(_ sender: Any) {
        currentViewController?.popViewController(animated: true)
        currentViewController?.dismiss(animated: true, completion: nil)
    }
}
