//
//  WebViewController.swift
//  Plutope
//
//  Created by Priyanka Poojara on 21/06/23.
//

import UIKit
import WebKit

class WebViewController: UIViewController {
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var headerView: UIView!
  
    var webViewURL: String = "www.google.com"
    var webTitle: String = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        defineHeader(headerView: headerView, titleText: webTitle, btnBackHidden: false)
        webView.uiDelegate = self
        webView.navigationDelegate = self
        
        webView.load(webViewURL)
        
    }
    
    @MainActor
    func showWebView(for url: String, title: String, onVC: UIViewController) {
        let webController = WebViewController()
        webController.webViewURL = url
        webController.webTitle = title
        let navVC = UINavigationController(rootViewController: webController)
        navVC.modalPresentationStyle = .overFullScreen
        navVC.modalTransitionStyle = .crossDissolve
        onVC.present(navVC, animated: true)
    }
}

extension WebViewController: WKUIDelegate, WKNavigationDelegate {
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
    }
    
}
